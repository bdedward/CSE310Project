//This is a header file for the utils.cpp file

#include<cstdlib>
#include<cstring>
#include<iostream>
#include<fstream>
#include<string>
#include<limits.h>
#include<math.h>

int nextCommand(int*, int*, int*);
